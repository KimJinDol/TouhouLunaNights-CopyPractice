
#include "AIBase.h"

CAIBase::CAIBase() 
    // m_isComplete(true)
{
}

CAIBase::~CAIBase()
{
}

bool CAIBase::Init()
{
    // m_isComplete = true;

    return true;
}


#include "AIAttack.h"
#include "../Object/AI.h"
#include "../Resource/Animation.h"
#include "../Scene/Scene.h"
#include "AIController.h"

CAIAttack::CAIAttack()
{
}

CAIAttack::~CAIAttack()
{
}

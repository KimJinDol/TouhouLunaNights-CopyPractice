
#include "AIIdle.h"
#include "../Object/AI.h"
#include "../Resource/Animation.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneMode.h"
#include "AIController.h"

CAIIdle::CAIIdle()
{
}

CAIIdle::~CAIIdle()
{
}

void CAIIdle::Run(class CAIController* pController, CAICharacter* pOwner, CScene* pScene, float DeltaTime)
{
	// idle�� ���õ� �� ����..
}

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// GameFramework.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDI_ICON1                       101
#define IDD_DIALOG1                     102
#define IDC_EDIT_TILECOUNTX             1001
#define IDC_EDIT_TILECOUNTY             1002
#define IDC_EDIT_TILESIZEX              1003
#define IDC_EDIT_TILESIZEY              1004
#define IDC_BUTTON_CREATE               1006
#define IDC_BUTTON_SAVE                 1007
#define IDC_BUTTON_LOAD                 1008
#define IDC_COMBO_TILETYPE              1011
#define IDC_TILETMODE                   1012
#define IDC_TILEEDITMODE                1012
#define IDC_COMBO_TILEEDITMODE          1013
#define IDC_TILETYPE2                   1014
#define IDC_TILETYPE                    1014
#define IDC_COMBO_TILERESOURCE          1015
#define IDC_BUTTON_LOADBACKTEXTURE      1016
#define IDC_SPIN1                       1016
#define IDC_TILERESOURCE                1017
#define IDC_EDIT_TILESTARTPOSX          1018
#define IDC_EDIT_TILESTARTPOSY          1019
#define IDC_BUTTON_LOADBACKGROUNDTEXTURE 1020
#define IDC_BUTTON_LOADTILEIMAGE        1020
#define IDC_BUTTON_LOADBACKGROUNDTEXTURE2 1021
#define IDC_COMBO_TILETYPE2             1021
#define IDC_COMBO_TILECOLLISION         1021
#define IDC_TILECOLLISION               1022
#define IDC_STAGEEXPEND                 1023
#define IDC_BUTTON_TILECLEAR            1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
